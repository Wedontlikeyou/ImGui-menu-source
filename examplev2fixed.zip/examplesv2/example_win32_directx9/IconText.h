#define ICON_MIN 0x000
#define ICON_MAX 0x002

#define ICON_TEST u8"\ue000" //0xe04a

