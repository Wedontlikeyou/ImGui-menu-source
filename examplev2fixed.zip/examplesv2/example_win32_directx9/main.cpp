// Dear ImGui: standalone example application for DirectX 9
// If you are new to Dear ImGui, read documentation from the docs/ folder + read the top of imgui.cpp.
// Read online: https://github.com/ocornut/imgui/tree/master/docs

#include "imgui.h"
#include "imgui_impl_dx9.h"
#include "imgui_impl_win32.h"
#include <d3d9.h>
#include <tchar.h>
#include <string>

//Texteditor
#include "Texteditor.h"

//icons
#include <vector>


// Data
static LPDIRECT3D9              g_pD3D = NULL;
static LPDIRECT3DDEVICE9        g_pd3dDevice = NULL;
static D3DPRESENT_PARAMETERS    g_d3dpp = {};

// Forward declarations of helper functions
bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void ResetDevice();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Main code
int main(int, char**)
{
    // Create application window
    //ImGui_ImplWin32_EnableDpiAwareness();
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(NULL), NULL, NULL, NULL, NULL, _T("ImGui Example"), NULL };
    ::RegisterClassEx(&wc);
    HWND hwnd = ::CreateWindow(wc.lpszClassName, _T("Dear ImGui DirectX9 Example"), WS_OVERLAPPEDWINDOW, 100, 100, 1280, 800, NULL, NULL, wc.hInstance, NULL);

    // Initialize Direct3D
    if (!CreateDeviceD3D(hwnd))
    {
        CleanupDeviceD3D();
        ::UnregisterClass(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    // Show the window
    ::ShowWindow(hwnd, SW_SHOWDEFAULT);
    ::UpdateWindow(hwnd);

    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    //io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
    //io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls

    // Setup Dear ImGui style
    ImGuiStyle* style = &ImGui::GetStyle();

    //background
    style->Colors[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
    style->Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
    style->Colors[ImGuiCol_FrameBgActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
    style->Colors[ImGuiCol_WindowBg] = ImVec4(0.078f, 0.067f, 0.063f, 1.00f);

    //button
    style->Colors[ImGuiCol_Button] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
    style->Colors[ImGuiCol_ButtonHovered] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
    style->Colors[ImGuiCol_ButtonActive] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
    style->Colors[ImGuiCol_ChildBg] = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);

    style->Colors[ImGuiCol_ModalWindowDimBg] = { 0.00f, 0.00f, 0.00f, 0.4f };
    //style->Colors[ImGuiCol_Modal] = { 0.00f, 0.00f, 0.00f, 0.4f };

    style->WindowBorderSize = 0.0f;


    style->WindowPadding = ImVec2(5, 5);
    style->WindowRounding = 0.0f;
    style->FramePadding = ImVec2(5, 5);
    style->FrameRounding = 2.0f;
    style->ItemSpacing = ImVec2(12, 8);
    style->ItemInnerSpacing = ImVec2(8, 6);
    style->IndentSpacing = 25.0f;
    style->ScrollbarSize = 15.0f;
    style->ScrollbarRounding = 9.0f;
    style->GrabMinSize = 5.0f;
    style->GrabRounding = 3.0f;
    //ImGui::GetStyle().
    //ImGui::StyleColorsClassic();

    // Setup Platform/Renderer backends
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX9_Init(g_pd3dDevice);


    ImFont* normalfont = io.Fonts->AddFontFromFileTTF("Fonts/Roboto-Medium.ttf", 16.0f);
    ImFont* windowsfont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\Arialbd.ttf", 20.0f);
    ImFont* titlefont = io.Fonts->AddFontFromFileTTF("Fonts/Oswald-Bold.ttf", 106.0f);
    ImFont* modalfont = io.Fonts->AddFontFromFileTTF("Fonts/Roboto-Medium.ttf", 20.0f);
    ImFont* iconfont = io.Fonts->AddFontFromFileTTF("Fonts/icons.ttf", 56.0f);
    ImFont* iconfontbig = io.Fonts->AddFontFromFileTTF("Fonts/icons.ttf", 110.0f);


    // Our state
    ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

    // Main loop
    bool done = false;
    bool FPSCOUNTER = false;
    bool MENULOAD = false;
    bool firstmenu = true;

    //Here are the tabs located.
    bool dumpertab = false;
    bool executortab = false;
    bool resourcetab = false;

    while (!done)
    {
        // Poll and handle messages (inputs, window resize, etc.)
        // See the WndProc() function below for our to dispatch events to the Win32 backend.
        MSG msg;
        while (::PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        // Start the Dear ImGui frame
        ImGui_ImplDX9_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        //ImGui::ShowDemoWindow();


        if (MENULOAD == false)
        {

        }
        else
        {




            if (firstmenu == true)
            {
                ImGui::Begin("Wedontlikeyou.EXE", 0, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize);
                ImGui::SetWindowPos(ImVec2(700, 200));
                ImGui::PushFont(titlefont);
                ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(89, 88, 89, 255));
                ImGui::SameLine(0);
                ImGui::Text("Wedontlikeyou");
                ImGui::PopStyleColor();
                ImGui::SameLine(445);
                ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(102, 93, 179, 255));
                ImGui::Text(".exe");
                ImGui::PopStyleColor();
                ImGui::PopFont();
                ImGui::End();
            }

            ImGui::OpenPopup("A");
            if (ImGui::BeginPopupModal("A", NULL, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiCond_FirstUseEver))
            {
                ImGui::SetWindowSize(ImVec2(1920, 1080), 0);
                ImGui::SetWindowPos(ImVec2(730, 400));






                //TABS Needs to be located in the Modal because it wont be on top if it isnt





                if (dumpertab == true)
                {
                    ImGui::Begin("Dumper", 0, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize);                          // Create a window called "Hello, world!" and append into it.
                    ImGui::SetWindowSize(ImVec2(800, 700));

                    //TITLE
                    ImGui::PushFont(titlefont);
                    ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(89, 88, 89, 255));
                    ImGui::SameLine(255);
                    ImGui::Text("Dumper");
                    ImGui::PopStyleColor();
                    ImGui::PopFont();
                    //TITLE

                    ImGui::Text(" "); //SPACE
                    ImGui::SameLine();
                    ImGui::BeginChildFrame(123, ImVec2(755, 570));
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(ImColor(102, 93, 179, 255)));
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(ImColor(68, 62, 119, 255)));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(ImColor(130, 126, 164, 255)));
                    ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(0, 0, 0, 20));


                    static std::vector<std::string> dumps =
                    {
                        "lachmachun",
                        "essentialmode",
                        "mysql-async",
                        "kebab",
                        "es_wedontlikeyou",
                        "async",
                        "deeznuts",
                        "pushinP"
                    };

                    static ImGuiTextFilter searchf;
                    searchf.Draw("Search", 685);

                    if (ImGui::ListBoxHeader("##Dumps", ImVec2(145, 480)))
                    {
                        for (const auto& dumpsz : dumps)
                        {
                            if (searchf.PassFilter(dumpsz.c_str()))
                            {
                                if (ImGui::TreeNode(dumpsz.c_str()))
                                    ImGui::TreePop();
                            }
                        }
                        ImGui::ListBoxFooter();
                    }

                    ImGui::SameLine(160);
                    ImGui::PushFont(modalfont);
                    static TextEditor dumpingdeeznutswindow;
                    dumpingdeeznutswindow.SetReadOnly(1);
                    dumpingdeeznutswindow.Render("##Dumpviewer", ImVec2(587, 480));
                    ImGui::PopFont();
                    

                    ImGui::PopStyleColor();
                    if (ImGui::Button("Dump resources to folder", ImVec2(550, 34)))
                    {

                    }

                    ImGui::SameLine();
                    if (ImGui::Button("Return", ImVec2(180, 34)))
                    {
                        dumpertab = false;
                        firstmenu = true;
                    }

                    ImGui::PopStyleColor(3);
                    ImGui::EndChildFrame();

                    ImGui::End();
                }












                if (resourcetab == true)
                {
                    ImGui::Begin("Resource", 0, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize);                          // Create a window called "Hello, world!" and append into it.
                    ImGui::SetWindowSize(ImVec2(800, 700));

                    //TITLE
                    ImGui::PushFont(titlefont);
                    ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(89, 88, 89, 255));
                    ImGui::SameLine(255);
                    ImGui::Text("Resource");
                    ImGui::PopStyleColor();
                    ImGui::PopFont();
                    //TITLE

                    ImGui::Text(" "); //SPACE
                    ImGui::SameLine();
                    ImGui::BeginChildFrame(123, ImVec2(755, 570));
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(ImColor(102, 93, 179, 255)));
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(ImColor(68, 62, 119, 255)));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(ImColor(130, 126, 164, 255)));
                    ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(0, 0, 0, 20));


                    static std::vector<std::string> dumps =
                    {
                        "lachmachun",
                        "essentialmode",
                        "mysql-async",
                        "kebab",
                        "es_wedontlikeyou",
                        "async",
                        "deeznuts",
                        "pushinP"
                    };

                    static ImGuiTextFilter searchf;
                    searchf.Draw("Search", 685);

                    if (ImGui::ListBoxHeader("##Resources", ImVec2(745, 480)))
                    {
                        for (const auto& dumpsz : dumps)
                        {
                            if (searchf.PassFilter(dumpsz.c_str()))
                            {
                                if (ImGui::TreeNode(dumpsz.c_str()))
                                    ImGui::TreePop();
                            }
                        }
                        ImGui::ListBoxFooter();
                    }
                    ImGui::PopStyleColor();
                    if (ImGui::Button("Check for resource", ImVec2(550, 34)))
                    {

                    }

                    ImGui::SameLine();
                    if (ImGui::Button("Return", ImVec2(180, 34)))
                    {
                        resourcetab = false;
                        firstmenu = true;
                    }

                    ImGui::PopStyleColor(3);
                    ImGui::EndChildFrame();

                    ImGui::End();
                }

                if (executortab == true)
                {
                    ImGui::Begin("Executor", 0, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize);                          // Create a window called "Hello, world!" and append into it.
                    ImGui::SetWindowSize(ImVec2(800, 700));

                    //TITLE
                    ImGui::PushFont(titlefont);
                    ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(89, 88, 89, 255));
                    ImGui::SameLine(255);
                    ImGui::Text("Executor");
                    ImGui::PopStyleColor();
                    ImGui::PopFont();
                    //TITLE

                    ImGui::Text(" "); //SPACE
                    ImGui::SameLine();
                    ImGui::BeginChildFrame(123, ImVec2(755, 570));


                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(ImColor(102, 93, 179, 255)));
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(ImColor(68, 62, 119, 255)));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(ImColor(130, 126, 164, 255)));
                    ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(0, 0, 0, 20));

                    if (ImGui::Button("Clear", ImVec2(150, 34)))
                    {

                    }

                    ImGui::SameLine();

                    if (ImGui::Button("Open lua script from file", ImVec2(220, 34)))
                    {

                    }

                    ImGui::SameLine();

                    static ImGuiTextFilter searchex;
                    searchex.Draw("Search", 300);




                    ImGui::PushFont(modalfont);
                    static TextEditor executordeeznutswindow;

                    executordeeznutswindow.Render("##Executoreditor", ImVec2(745, 480));
                    ImGui::PopFont();

                    ImGui::PopStyleColor();



                    if (ImGui::Button("Execute", ImVec2(550, 34)))
                    {

                    }

                    ImGui::SameLine();
                    if (ImGui::Button("Return", ImVec2(180, 34)))
                    {
                        executortab = false;
                        firstmenu = true;
                    }



                    ImGui::PopStyleColor(3);
                    ImGui::EndChildFrame();

                    ImGui::End();
                }




                if (firstmenu == true)
                {
                //ICONS
                ImGui::PushFont(iconfontbig);
                if  (ImGui::Button("L")) //executor
                {
                    firstmenu = false;
                    executortab = true;
                }
                ImGui::SameLine(200);
                if (ImGui::Button("S")) //resource
                {
                    firstmenu = false;
                    resourcetab = true;
                }
                ImGui::SameLine(400);
                if (ImGui::Button("Q")) //dumper
                {
                    firstmenu = false;
                    dumpertab = true;
                }
                ImGui::PopFont();
                //ICONS

                ImGui::PushFont(modalfont);

                //color
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(ImColor(102, 93, 179, 255)));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(ImColor(102, 93, 179, 255)));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(ImColor(102, 93, 179, 255)));
                //color


                ImGui::Button("EXECUTOR", ImVec2(114.0f, 0.0f)); //executor
                ImGui::SameLine(200);
                ImGui::Button("RESOURCE", ImVec2(114.0f, 0.0f)); //dumper
                ImGui::SameLine(400);
                ImGui::Button("DUMPER", ImVec2(114.0f, 0.0f)); //dumper
                ImGui::PopFont();
                ImGui::PopStyleColor(3);
                //EXEUCOTR
                }

                ImGui::EndPopup();
            }

            //BACKGROUND
            ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 10.0f);
            ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(ImColor(255, 0, 0, 0)));
            ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(ImColor(68, 62, 119, 255)));

            ImGui::Begin("Background", 0,  ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavFocus);
            {
                ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(ImColor(255, 0, 0, 0)));

                ImGui::SetWindowSize(ImVec2(1920, 1017), 0);
                ImGui::SetWindowPos(ImVec2(0, 0));
                ImGui::PopStyleColor();
                ImGui::End();
            }

            ImGui::PopStyleColor(2);
            ImGui::PopStyleVar();
            //BACKGROUND

            ImGui::Begin("FPS", 0, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiCond_FirstUseEver);
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(102, 93, 179, 255));
            ImGui::SetWindowPos(ImVec2(3, 970));
            ImGui::PushFont(windowsfont);
            ImGui::Text("FPS %.3f", ImGui::GetIO().Framerate, ImVec2(0, 0));
            ImGui::PopStyleColor();
            ImGui::PopFont(); //fps
            ImGui::End();

            ImGui::Begin("Buildver", 0, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiCond_FirstUseEver);
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(102, 93, 179, 255));
            ImGui::SetWindowPos(ImVec2(3, 987));
            ImGui::PushFont(windowsfont);
            ImGui::Text("Build version 1.0");
            ImGui::PopStyleColor();
            ImGui::PopFont(); //version
            ImGui::End();
        }

        if (GetAsyncKeyState(VK_DELETE) & 1)
            if (MENULOAD == false)
            {
                MENULOAD = true;
            }
            else
            {
                MENULOAD = false;
            }


        // Rendering
        ImGui::EndFrame();
        g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, FALSE);
        g_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
        g_pd3dDevice->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        D3DCOLOR clear_col_dx = D3DCOLOR_RGBA((int)(clear_color.x*clear_color.w*255.0f), (int)(clear_color.y*clear_color.w*255.0f), (int)(clear_color.z*clear_color.w*255.0f), (int)(clear_color.w*255.0f));
        g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, clear_col_dx, 1.0f, 0);
        if (g_pd3dDevice->BeginScene() >= 0)
        {
            ImGui::Render();
            ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
            g_pd3dDevice->EndScene();
        }
        HRESULT result = g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

        // Handle loss of D3D9 device
        if (result == D3DERR_DEVICELOST && g_pd3dDevice->TestCooperativeLevel() == D3DERR_DEVICENOTRESET)
            ResetDevice();
    }

    ImGui_ImplDX9_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClass(wc.lpszClassName, wc.hInstance);

    return 0;
}

// Helper functions

bool CreateDeviceD3D(HWND hWnd)
{
    if ((g_pD3D = Direct3DCreate9(D3D_SDK_VERSION)) == NULL)
        return false;

    // Create the D3DDevice
    ZeroMemory(&g_d3dpp, sizeof(g_d3dpp));
    g_d3dpp.Windowed = TRUE;
    g_d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    g_d3dpp.BackBufferFormat = D3DFMT_UNKNOWN; // Need to use an explicit format with alpha if needing per-pixel alpha composition.
    g_d3dpp.EnableAutoDepthStencil = TRUE;
    g_d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
    g_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_ONE;           // Present with vsync
    //g_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;   // Present without vsync, maximum unthrottled framerate
    if (g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd, D3DCREATE_HARDWARE_VERTEXPROCESSING, &g_d3dpp, &g_pd3dDevice) < 0)
        return false;

    return true;
}

void CleanupDeviceD3D()
{
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = NULL; }
    if (g_pD3D) { g_pD3D->Release(); g_pD3D = NULL; }
}

void ResetDevice()
{
    ImGui_ImplDX9_InvalidateDeviceObjects();
    HRESULT hr = g_pd3dDevice->Reset(&g_d3dpp);
    if (hr == D3DERR_INVALIDCALL)
        IM_ASSERT(0);
    ImGui_ImplDX9_CreateDeviceObjects();
}

// Forward declare message handler from imgui_impl_win32.cpp
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Win32 message handler
// You can read the io.WantCaptureMouse, io.WantCaptureKeyboard flags to tell if dear imgui wants to use your inputs.
// - When io.WantCaptureMouse is true, do not dispatch mouse input data to your main application, or clear/overwrite your copy of the mouse data.
// - When io.WantCaptureKeyboard is true, do not dispatch keyboard input data to your main application, or clear/overwrite your copy of the keyboard data.
// Generally you may always pass all inputs to dear imgui, and hide them from your application based on those two flags.
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg)
    {
    case WM_SIZE:
        if (g_pd3dDevice != NULL && wParam != SIZE_MINIMIZED)
        {
            g_d3dpp.BackBufferWidth = LOWORD(lParam);
            g_d3dpp.BackBufferHeight = HIWORD(lParam);
            ResetDevice();
        }
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) // Disable ALT application menu
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProc(hWnd, msg, wParam, lParam);
}
